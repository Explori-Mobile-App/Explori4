
  # Explori  Mobile App

  This is a code bundle for Explori  Mobile App. The original project is available at https://www.figma.com/design/VgzaxLH9MAfzMpS90CEkXF/Explori--Mobile-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  