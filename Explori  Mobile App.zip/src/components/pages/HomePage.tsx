import { ReelFeed } from '../ReelFeed';
import { BottomNavigation } from '../BottomNavigation';
import { Page } from '../Router';

interface HomePageProps {
  onNavigate: (page: Page, data?: any) => void;
}

export default function HomePage({ onNavigate }: HomePageProps) {
  // Mock user state - in a real app this would come from authentication context
  const isSignedIn = false;

  return (
    <div className="flex flex-col min-h-full bg-black" data-bravo="[container]">
      {/* Reel Feed - Full Screen */}
      <div className="flex-1 relative" data-bravo="[container]">
        <ReelFeed onNavigate={onNavigate} isSignedIn={isSignedIn} />
      </div>
      
      {/* Fixed Bottom Navigation */}
      <div className="fixed bottom-0 left-1/2 transform -translate-x-1/2 w-full max-w-[393px] z-40">
        <div className="bg-gradient-to-t from-black/50 to-transparent pt-4 pb-2">
          <BottomNavigation currentPage="Home" onNavigate={onNavigate} />
        </div>
      </div>
    </div>
  );
}