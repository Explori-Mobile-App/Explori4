import { Search, Filter, MapPin } from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { BottomNavigation } from '../BottomNavigation';
import { Page } from '../Router';

interface MapPageProps {
  onNavigate: (page: Page, data?: any) => void;
}

export default function MapPage({ onNavigate }: MapPageProps) {
  const nearbyPlaces = [
    { name: "Coastal Café", type: "Restaurant", distance: "0.3 km", rating: 4.8 },
    { name: "Mountain View Hotel", type: "Hotel", distance: "0.8 km", rating: 4.6 },
    { name: "Central Park", type: "Park", distance: "1.2 km", rating: 4.9 },
    { name: "Art Gallery Downtown", type: "Culture", distance: "1.5 km", rating: 4.7 }
  ];

  return (
    <div className="flex flex-col min-h-full bg-[#fdfcfb]" data-bravo="[container]">
      {/* Header */}
      <div className="bg-white border-b border-[#e5e7eb] p-4 pt-12">
        <h1 className="text-xl font-medium text-[#1f2937] mb-4" data-bravo="[text]">Explore Map</h1>
        
        {/* Search Bar */}
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-[#64748b] w-4 h-4" />
            <Input
              placeholder="Search places..."
              className="pl-10"
              data-bravo="[input]"
            />
          </div>
          <Button variant="outline" size="sm" data-bravo="[button]">
            <Filter className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Map Area (Placeholder) */}
      <div className="flex-1 bg-gradient-to-br from-green-100 to-blue-100 relative overflow-hidden">
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="bg-white/90 backdrop-blur-sm rounded-xl p-8 text-center">
            <MapPin className="w-12 h-12 text-[#ff6b35] mx-auto mb-4" />
            <h3 className="font-medium text-[#1f2937] mb-2" data-bravo="[text]">Interactive Map</h3>
            <p className="text-sm text-[#64748b]" data-bravo="[text]">Map integration coming soon</p>
          </div>
        </div>
        
        {/* Map Pins (Visual placeholders) */}
        <div className="absolute top-20 left-16 w-6 h-6 bg-[#ff6b35] rounded-full flex items-center justify-center text-white text-xs">📍</div>
        <div className="absolute top-32 right-20 w-6 h-6 bg-[#ff6b35] rounded-full flex items-center justify-center text-white text-xs">🏨</div>
        <div className="absolute bottom-40 left-12 w-6 h-6 bg-[#ff6b35] rounded-full flex items-center justify-center text-white text-xs">🍽️</div>
        <div className="absolute bottom-32 right-16 w-6 h-6 bg-[#ff6b35] rounded-full flex items-center justify-center text-white text-xs">🎨</div>
      </div>

      {/* Nearby Places */}
      <div className="bg-white border-t border-[#e5e7eb] p-4 max-h-48 overflow-y-auto">
        <h3 className="font-medium text-[#1f2937] mb-3" data-bravo="[text]">Nearby Places</h3>
        <div className="space-y-2">
          {nearbyPlaces.map((place, index) => (
            <div key={index} className="flex items-center justify-between p-3 bg-[#f8f9fa] rounded-lg">
              <div className="flex-1">
                <h4 className="font-medium text-[#1f2937] text-sm" data-bravo="[text]">{place.name}</h4>
                <p className="text-xs text-[#64748b]" data-bravo="[text]">{place.type} • {place.distance} • {place.rating} ⭐</p>
              </div>
              <Button size="sm" variant="ghost" className="text-[#ff6b35]" data-bravo="[button]">
                View
              </Button>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom Navigation */}
      <BottomNavigation currentPage="Map" onNavigate={onNavigate} />
    </div>
  );
}