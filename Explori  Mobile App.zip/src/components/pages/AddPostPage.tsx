import { ArrowLeft, Camera, MapPin, Users } from 'lucide-react';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Textarea } from '../ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { BottomNavigation } from '../BottomNavigation';
import { Page } from '../Router';

interface AddPostPageProps {
  onNavigate: (page: Page, data?: any) => void;
}

export default function AddPostPage({ onNavigate }: AddPostPageProps) {
  const handlePublish = () => {
    alert('Post published successfully!');
    onNavigate('Home');
  };

  return (
    <div className="flex flex-col min-h-full bg-[#fdfcfb]" data-bravo="[container]">
      {/* Header */}
      <div className="bg-white border-b border-[#e5e7eb] p-4 pt-12">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onNavigate('Home')}
              data-bravo="[button]"
            >
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <h1 className="text-xl font-medium text-[#1f2937]" data-bravo="[text]">Share Experience</h1>
          </div>
          <Button 
            size="sm" 
            className="bg-[#ff6b35] hover:bg-[#e55a2b]"
            onClick={handlePublish}
            data-bravo="[button]"
          >
            Publish
          </Button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 p-6 space-y-6">
        {/* Photo Upload */}
        <div>
          <Label data-bravo="[text]">Add Photos</Label>
          <div className="mt-2 border-2 border-dashed border-[#e5e7eb] rounded-xl p-8 text-center bg-white">
            <Camera className="w-12 h-12 text-[#64748b] mx-auto mb-4" />
            <p className="text-[#64748b] mb-2" data-bravo="[text]">Tap to add photos</p>
            <p className="text-sm text-[#64748b]" data-bravo="[text]">Share up to 10 photos of your experience</p>
          </div>
        </div>

        {/* Post Type */}
        <div>
          <Label htmlFor="postType" data-bravo="[text]">What are you sharing?</Label>
          <Select>
            <SelectTrigger className="mt-2" data-bravo="[input]">
              <SelectValue placeholder="Select post type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="place">📍 Place Review</SelectItem>
              <SelectItem value="event">🎉 Event Experience</SelectItem>
              <SelectItem value="tip">💡 Travel Tip</SelectItem>
              <SelectItem value="adventure">🌟 Adventure Story</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Title */}
        <div>
          <Label htmlFor="title" data-bravo="[text]">Title</Label>
          <Input 
            id="title" 
            placeholder="Give your post a catchy title..."
            className="mt-2"
            data-bravo="[input]"
          />
        </div>

        {/* Description */}
        <div>
          <Label htmlFor="description" data-bravo="[text]">Description</Label>
          <Textarea 
            id="description" 
            placeholder="Tell us about your experience! What made it special? Any tips for other travelers?"
            className="mt-2 h-32"
            data-bravo="[input]"
          />
        </div>

        {/* Location */}
        <div>
          <Label htmlFor="location" data-bravo="[text]">Location</Label>
          <div className="mt-2 flex gap-2">
            <Input 
              id="location" 
              placeholder="Where was this?"
              className="flex-1"
              data-bravo="[input]"
            />
            <Button variant="outline" size="sm" data-bravo="[button]">
              <MapPin className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Tags */}
        <div>
          <Label htmlFor="tags" data-bravo="[text]">Tags</Label>
          <Input 
            id="tags" 
            placeholder="Add tags (e.g., #foodie, #adventure, #hidden-gem)"
            className="mt-2"
            data-bravo="[input]"
          />
        </div>

        {/* Privacy Settings */}
        <div className="bg-white rounded-xl p-4 border border-[#e5e7eb]">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Users className="w-5 h-5 text-[#64748b]" />
              <div>
                <p className="font-medium text-[#1f2937]" data-bravo="[text]">Who can see this?</p>
                <p className="text-sm text-[#64748b]" data-bravo="[text]">Public - Everyone on explori</p>
              </div>
            </div>
            <Button variant="outline" size="sm" data-bravo="[button]">
              Change
            </Button>
          </div>
        </div>
      </div>

      {/* Bottom Navigation */}
      <BottomNavigation currentPage="AddPost" onNavigate={onNavigate} />
    </div>
  );
}