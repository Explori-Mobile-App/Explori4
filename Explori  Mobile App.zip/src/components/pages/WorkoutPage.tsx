import { useState, useEffect } from 'react';
import { Play, Pause, Square, MapPin, Clock, Zap, Trophy, Plus } from 'lucide-react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { Progress } from '../ui/progress';
import { Page } from '../Router';
import { useCapacitor } from '../../hooks/useCapacitor';

interface WorkoutPageProps {
  onNavigate: (page: Page, data?: any) => void;
}

interface WorkoutSession {
  id: string;
  type: string;
  duration: number;
  calories: number;
  distance?: number;
  startTime: Date;
  isActive: boolean;
}

export default function WorkoutPage({ onNavigate }: WorkoutPageProps) {
  const [activeWorkout, setActiveWorkout] = useState<WorkoutSession | null>(null);
  const [workoutTime, setWorkoutTime] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const { triggerHaptic } = useCapacitor();

  const recentWorkouts = [
    {
      id: '1',
      type: 'Morning Run',
      duration: 35,
      calories: 320,
      distance: 5.2,
      date: 'Today',
      location: 'Central Park, NYC'
    },
    {
      id: '2',
      type: 'Yoga Session',
      duration: 45,
      calories: 180,
      date: 'Yesterday',
      location: 'Bryant Park, NYC'
    },
    {
      id: '3',
      type: 'Cycling',
      duration: 60,
      calories: 480,
      distance: 15.8,
      date: '2 days ago',
      location: 'Brooklyn Bridge'
    }
  ];

  const quickWorkouts = [
    { name: 'Quick Run', icon: '🏃‍♂️', duration: '20 min', type: 'running' },
    { name: 'Yoga Flow', icon: '🧘‍♀️', duration: '30 min', type: 'yoga' },
    { name: 'HIIT Workout', icon: '💪', duration: '15 min', type: 'hiit' },
    { name: 'Walking', icon: '🚶‍♂️', duration: '45 min', type: 'walking' }
  ];

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isRunning && activeWorkout) {
      interval = setInterval(() => {
        setWorkoutTime(prev => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isRunning, activeWorkout]);

  const startWorkout = (type: string) => {
    triggerHaptic('medium');
    const newWorkout: WorkoutSession = {
      id: Date.now().toString(),
      type,
      duration: 0,
      calories: 0,
      startTime: new Date(),
      isActive: true
    };
    setActiveWorkout(newWorkout);
    setWorkoutTime(0);
    setIsRunning(true);
  };

  const pauseWorkout = () => {
    triggerHaptic('light');
    setIsRunning(!isRunning);
  };

  const stopWorkout = () => {
    triggerHaptic('heavy');
    if (activeWorkout) {
      const finalWorkout = {
        ...activeWorkout,
        duration: Math.floor(workoutTime / 60),
        calories: Math.floor(workoutTime * 0.15), // Rough estimate
        isActive: false
      };
      // Save workout (would be to backend/local storage)
      console.log('Workout completed:', finalWorkout);
    }
    setActiveWorkout(null);
    setWorkoutTime(0);
    setIsRunning(false);
  };

  const formatTime = (seconds: number) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    if (hrs > 0) {
      return `${hrs}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      {/* Header */}
      <div className="bg-white/80 backdrop-blur-sm border-b border-slate-200/50 px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">Workouts</h1>
            <p className="text-slate-600">Track your fitness journey</p>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => onNavigate('Routes')}
            className="gradient-secondary text-white border-0"
          >
            <MapPin className="w-4 h-4 mr-2" />
            Routes
          </Button>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* Active Workout */}
        {activeWorkout && (
          <Card className="glass-bg border-0 shadow-xl">
            <CardHeader className="text-center">
              <CardTitle className="text-xl text-indigo-600">
                {activeWorkout.type}
              </CardTitle>
              <div className="text-4xl font-bold text-slate-900 font-mono">
                {formatTime(workoutTime)}
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <p className="text-2xl font-bold text-orange-600">
                    {Math.floor(workoutTime * 0.15)}
                  </p>
                  <p className="text-sm text-slate-600">Calories</p>
                </div>
                <div>
                  <p className="text-2xl font-bold text-blue-600">
                    {(workoutTime / 60).toFixed(1)}
                  </p>
                  <p className="text-sm text-slate-600">Minutes</p>
                </div>
                <div>
                  <p className="text-2xl font-bold text-green-600">
                    {((workoutTime / 60) * 0.1).toFixed(1)}
                  </p>
                  <p className="text-sm text-slate-600">km</p>
                </div>
              </div>

              <div className="flex gap-3">
                <Button
                  onClick={pauseWorkout}
                  className="flex-1"
                  variant={isRunning ? "outline" : "default"}
                >
                  {isRunning ? (
                    <>
                      <Pause className="w-4 h-4 mr-2" />
                      Pause
                    </>
                  ) : (
                    <>
                      <Play className="w-4 h-4 mr-2" />
                      Resume
                    </>
                  )}
                </Button>
                <Button
                  onClick={stopWorkout}
                  variant="destructive"
                  className="flex-1"
                >
                  <Square className="w-4 h-4 mr-2" />
                  Stop
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Quick Start Workouts */}
        {!activeWorkout && (
          <Card className="glass-bg border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-yellow-500" />
                Quick Start
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-3">
                {quickWorkouts.map((workout) => (
                  <button
                    key={workout.name}
                    onClick={() => startWorkout(workout.name)}
                    className="p-4 bg-white/50 rounded-xl border border-slate-200/50 hover:bg-white/80 transition-all active:scale-95"
                  >
                    <div className="text-2xl mb-2">{workout.icon}</div>
                    <h3 className="font-semibold text-slate-900">{workout.name}</h3>
                    <p className="text-sm text-slate-600">{workout.duration}</p>
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Today's Stats */}
        <Card className="glass-bg border-0 shadow-lg">
          <CardHeader>
            <CardTitle>Today's Progress</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Daily Goal</span>
                <span>320/500 calories</span>
              </div>
              <Progress value={64} className="h-2" />
            </div>
            
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <p className="text-xl font-bold text-indigo-600">35</p>
                <p className="text-sm text-slate-600">Minutes</p>
              </div>
              <div>
                <p className="text-xl font-bold text-green-600">5.2</p>
                <p className="text-sm text-slate-600">km</p>
              </div>
              <div>
                <p className="text-xl font-bold text-orange-600">320</p>
                <p className="text-sm text-slate-600">Calories</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Recent Workouts */}
        <Card className="glass-bg border-0 shadow-lg">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Recent Workouts</CardTitle>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onNavigate('Achievements')}
            >
              <Trophy className="w-4 h-4 mr-2" />
              View All
            </Button>
          </CardHeader>
          <CardContent className="space-y-3">
            {recentWorkouts.map((workout) => (
              <div
                key={workout.id}
                onClick={() => onNavigate('WorkoutDetail', workout)}
                className="p-4 bg-white/50 rounded-xl border border-slate-200/50 hover:bg-white/80 transition-all cursor-pointer"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-semibold text-slate-900">{workout.type}</h3>
                    <div className="flex items-center gap-2 text-sm text-slate-600">
                      <Clock className="w-3 h-3" />
                      <span>{workout.duration} min</span>
                      <span>•</span>
                      <span>{workout.calories} cal</span>
                      {workout.distance && (
                        <>
                          <span>•</span>
                          <span>{workout.distance} km</span>
                        </>
                      )}
                    </div>
                    <div className="flex items-center gap-1 text-xs text-slate-500 mt-1">
                      <MapPin className="w-3 h-3" />
                      <span>{workout.location}</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge variant="secondary">{workout.date}</Badge>
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}